from enum import IntEnum

class Type(IntEnum):
	NUMBER = 0
	BOOLEAN = 1
	STRING = 2