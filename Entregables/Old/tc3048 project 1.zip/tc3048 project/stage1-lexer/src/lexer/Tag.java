package lexer;

public class Tag {
	public final static int
		EOF = 65535, ERROR = 65534,

		/* OPERATORS */
		GEQ = 258, LEQ = 259, NEQ = 260,

		/* REGULAR EXPRESSIONS */
		ID = 357, NUMBER = 358, STRING = 359, TRUE = 360, FALSE = 361,

		/* RESERVED WORDS */
		MAKE = 457;

		FORWARD  = FD = 557;
		BACKWARD = BK = 558;
 		RIGHT = RT = 559;
		LEFT = LT =  560;
		CLEAR = CLS =  561;
		CIRCLE = 562;
		PENUP = PU = 563;
		PENDOWN = PD = 564;
		COLOR = 565;
		PENWIDTH =  566;
		IF= 567;
		IFELSE= 568;
		AND= 569;
		OR= 570;
		MOD= 571;
}
