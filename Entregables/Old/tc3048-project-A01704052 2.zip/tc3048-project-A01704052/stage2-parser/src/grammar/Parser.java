package grammar;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.LinkedHashSet;

import errors.SyntaxError;
import lexer.Lexer;
import lexer.Tag;
import lexer.Token;

public class Parser {
	private Lexer lexer;
	private Token token;
	private LinkedHashSet<Integer> firstPrimaryExpression = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstUnaryExpression = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstExtendedMultiplicativeExpression = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstMultiplicativeExpression = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstExtendedAdditiveExpression = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstAdditiveExpression = new LinkedHashSet<Integer>();
	
	private LinkedHashSet<Integer> firstRelationalExpression = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstExtendedRelationalExpression = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstEqualityExpression = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstExtendedEqualityExpression = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstConditionalTerm = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstExtendedConditionalTerm = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstConditionalExpression = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstExtendedConditionalExpression = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstExpression = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstIfTrue = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstIfFalse = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstIfElseStatement = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstIfStatement = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstConditionalStatement = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstRepetitiveStatement = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstStructuredStatement = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstListElement = new LinkedHashSet<Integer>();
	private LinkedHashSet<Integer> firstElement = new LinkedHashSet<Integer>();
	
	public Parser (FileInputStream input) {
		lexer = new Lexer(input);
		
		firstPrimaryExpression.add(Tag.ID); firstPrimaryExpression.add(Tag.NUMBER);
		firstPrimaryExpression.add(Tag.TRUE); firstPrimaryExpression.add(Tag.FALSE);
		firstPrimaryExpression.add((int) '(');
		
		firstUnaryExpression.add((int) '-'); firstUnaryExpression.add((int) '!');
		firstUnaryExpression.addAll(firstPrimaryExpression);
		
		firstExtendedMultiplicativeExpression.add((int) '*'); firstExtendedMultiplicativeExpression.add((int) '/');
		firstExtendedMultiplicativeExpression.add(Tag.MOD);
		
		firstMultiplicativeExpression.containsAll(firstUnaryExpression);
		
		firstExtendedAdditiveExpression.add((int) '+'); firstExtendedAdditiveExpression.add((int) '-');
		
		firstAdditiveExpression.addAll(firstMultiplicativeExpression);
		firstExtendedRelationalExpression.add((int) '<'); firstExtendedRelationalExpression.add(Tag.LEQ);
		firstExtendedRelationalExpression.add((int) '>'); firstExtendedRelationalExpression.add(Tag.GEQ);
		firstRelationalExpression.addAll(firstAdditiveExpression);
		firstExtendedEqualityExpression.add((int) '='); firstExtendedEqualityExpression.add(Tag.NEQ);
		firstEqualityExpression.addAll(firstRelationalExpression);
		firstExtendedConditionalTerm.add(Tag.AND);
		firstConditionalTerm.addAll(firstEqualityExpression);
		firstExtendedConditionalExpression.add(Tag.OR);
		firstConditionalExpression.addAll(firstConditionalTerm);
		firstexpression.addAll(firstConditionalExpression);
		firstIfFalse.addAll(firstStatementSequence);
		firstIfTrue.addAll(firstStatementSequence);
		firstIfElseStatement.add(Tag.IFELSE);
		firstIfStatement.add(Tag.IF);
		firstConditionalStatement.addAll(firstIfStatement);firstConditionalStatement.addAll(firstIfElseStatement);
		firstRepetitivelStatement.add(Tag.REPEAT);
		firstStructuredStatement.addAll(firstRepetitivelStatement);firstStructuredStatement.addAll(firstConditionalStatement);
		firstListElement.add((int) ',');
		firstElement.add(Tag.STRING);firstElement.addAll(firstexpression);
	}

	private void check(int tag) throws SyntaxError, IOException {
		if (token.getTag() == tag) {
			token = lexer.scan();
		} else {
			throw new SyntaxError();
		}
	}

	public void analyze() throws SyntaxError, IOException {
		token = lexer.scan();
		program();
	}
	
	private void primaryExpression() throws SyntaxError, IOException {
		if (firstPrimaryExpression.contains(token.getTag())) {
			switch(token.getTag()) {
			case Tag.ID : check(Tag.ID); break;
			case Tag.NUMBER : check(Tag.NUMBER); break;
			case Tag.TRUE : check(Tag.TRUE); break;
			case Tag.FALSE : check(Tag.FALSE); break;
			case ((int) '(') :
				check((int) '(');
				expression();
				check((int) ')');
				break;
			}
		} else {
			throw new SyntaxError();
		}
	}
	
	private void unaryExpression() throws SyntaxError, IOException {
		if (firstUnaryExpression.contains(token.getTag())) {
			switch(token.getTag()) {
			case ((int) '-') : check((int) '-'); unaryExpression(); break;
			case ((int) '!') : check((int) '!'); unaryExpression(); break;
			default			 : primaryExpression(); break;
			}
		}
	}
	
	private void extendedMultiplicativeExpression() throws SyntaxError, IOException {
		if (firstExtendedMultiplicativeExpression.contains(token.getTag())) {
			switch(token.getTag()) {
			case ((int) '*') : 
				check((int) '*');
				unaryExpression();
				extendedMultiplicativeExpression();
				break;
			case ((int) '/') : 
				check((int) '/');
				unaryExpression();
				extendedMultiplicativeExpression();
				break;
			case Tag.MOD : 
				check(Tag.MOD);
				unaryExpression();
				extendedMultiplicativeExpression();
				break;
			}
		} else {
			// do nothing
		}
	}
	
	protected void multiplicativeExpression() throws SyntaxError, IOException {
		if (firstMultiplicativeExpression.contains(token.getTag())) {
			unaryExpression();
			extendedMultiplicativeExpression();
		}
	}
	
	protected void extendedAdditiveExpression() throws SyntaxError, IOException {
		if (firstExtendedAdditiveExpression.contains(token.getTag())) {
			switch(token.getTag()) {
			case ((int) '+') : 
				check((int) '+');
				multiplicativeExpression();
				extendedAdditiveExpression();
				break;
			case ((int) '-') : 
				check((int) '-');
				multiplicativeExpression();
				extendedAdditiveExpression();
				break;
			}
		} else {
			// do nothing
		}
	}
	
	protected void additiveExpression() throws SyntaxError, IOException {
		if (firstAdditiveExpression.contains(token.getTag())) {
			multiplicativeExpression();
			extendedAdditiveExpression();
		}
	}

	protected void relationalExpression() throws SyntaxError, IOException {
		if (firstRelationalExpression.contains(token.getTag())) {
			additiveExpression();
			extendedRelationalExpression();
		}
	}
	protected void extendedRelationalExpression() throws SyntaxError, IOException {
		if (firstExtendedRelationalExpression.contains(token.getTag())) {
			switch(token.getTag()) {
			case ((int) '<') : 
				check((int) '<');
				additiveExpression();
				extendedRelationalExpression();
				break;
			case Tag.LEQ :  //LEQ =  "<=" on word file 
				check(Tag.LEQ);
				additiveExpression();
				extendedRelationalExpression(); 
				break;
			case ((int) '>') : 
				check((int) '>');
				additiveExpression();
				extendedRelationalExpression();
				break;
			case Tag.GEQ : //GEQ =  ">=" on word file 
				check(Tag.GEQ);
				additiveExpression();
				extendedRelationalExpression();
				break;
			}
		}else {
			// do nothing
		}
	}
	protected void equalityExpression() throws SyntaxError, IOException {
		if (firstEqualityExpression.contains(token.getTag())) {
			relationalExpression();
			extendedEqualityExpression();
		}
	}
	protected void extendedEqualityExpression() throws SyntaxError, IOException {
		if (firstExtendedEqualityExpression.contains(token.getTag())) {
			switch(token.getTag()) {
			case ((int) '=') : 
				check((int) '=');
				relationalExpression();
				extendedEqualityExpression();
				break;
			case (Tag.NEQ) : //NEQ =  "<>" on word file 
				check(Tag.NEQ);
				relationalExpression();
				extendedEqualityExpression();
				break;
			}
		}else {
			// do nothing
		}
	}
	
	protected void conditionalTerm() throws SyntaxError, IOException {
		if (firstConditionalTerm.contains(token.getTag())) {
			equalityExpression();
			extendedConditionalTerm();
		}
	}
	protected void extendedConditionalTerm() throws SyntaxError, IOException {
		if (firstExtendedConditionalTerm.contains(token.getTag())) {
			switch(token.getTag()) {
			case (Tag.AND) : 
				check(Tag.AND); //AND =  "and" on lexer file 
				equalityExpression();
				extendedConditionalTerm();
				break;
			}
		}
	}
	
	protected void conditionalExpression() throws SyntaxError, IOException {
		if (firstConditionalExpression.contains(token.getTag())) {
			conditionalTerm();
			extendedConditionalExpression();
		}
	}
	protected void extendedConditionalExpression() throws SyntaxError, IOException {
		if (firstExtendedConditionalExpression.contains(token.getTag())) {
			switch(token.getTag()) {
			case (Tag.OR) : 
				check(Tag.OR);
				conditionalTerm();
				extendedConditionalExpression();
				break;
			}
		}
	}
	
	protected void expression() throws SyntaxError, IOException {
		if (firstexpression.contains(token.getTag())) {
			conditionalExpression();
		}
	}
	
	protected void ifTrue() throws SyntaxError, IOException {
		if (firstIfTrue.contains(token.getTag())) {
			statementSequence();
		}
	}
	protected void ifFalse() throws SyntaxError, IOException {
		if (firstIfFalse.contains(token.getTag())) {
			statementSequence();
		}
	}
	
	protected void ifElseStatement() throws SyntaxError, IOException {
		if (firstIfElseStatement.contains(token.getTag())) {
			check(Tag.IFELSE);  //IFELSE =  "IFELSE" on lexer file 
			expression();
			check((int) '[');  
			ifTrue();
			check((int) ']');  
			check((int) '[');  
			ifFalse();
			check((int) ']');  
			
		}
	}
	
	protected void ifStatement() throws SyntaxError, IOException {
		if (firstIfStatement.contains(token.getTag())) {
			check(Tag.IF);  //IF =  "if" on lexer file 
			expression();
			check((int) '[');  
			ifTrue();
			check((int) ']');  
			
		}
	}
	
	protected void conditionalStatement() throws SyntaxError, IOException {
		if (firstConditionalStatement.contains(token.getTag())) {
			if(firstIfStatement.contains(token.getTag())){
				ifStatement();
			}else {
				ifElseStatement();
			}
		}
	}
	protected void repetitivelStatement() throws SyntaxError, IOException {
		if (firstRepetitivelStatement.contains(token.getTag())) {
			check(Tag.REPEAT); //REPEAT =  "Repeat" on lexer file 
			expression();
			check((int) '[');  
			statementSequence();
			check((int) ']');
		}
	}
	protected void structuredStatement() throws SyntaxError, IOException {
		if (firstStructuredStatement.contains(token.getTag())) {
			if (firstRepetitivelStatement.contains(token.getTag())) {
				repetitivelStatement();
			}else {
				conditionalStatement();
			}
				
		}
	}
	protected void listElement() throws SyntaxError, IOException {
		if (firstListElement.contains(token.getTag())) {
			check((int) ',');  
			element();
			listElement();
		}
	}
	protected void element() throws SyntaxError, IOException {
		if (firstElement.contains(token.getTag())) {
			if(token.getTag()==Tag.STRING) {
				check(Tag.STRING); 
			}else {
				expression();
			}
		}
	}
}
