To run the script:

python firstFollows.py <text file>

The text file must contain a first line indicating the number N of lines
Followed by N lines containing the grammar